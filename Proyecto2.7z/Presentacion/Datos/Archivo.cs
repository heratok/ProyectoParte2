﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.IO;

namespace Datos
{
    public class Archivo
    {

        protected string ruta;
        protected string ruta1;
        protected string ruta2;
        public Archivo()
        {
            ruta = "Clientes.txt";
            //ruta1 = "familiar.txt";
            //ruta2 = "empresarial.txt";
        }

        public Archivo(string fileName)
        {
            ruta = fileName;
            //ruta1 = fileName;
            //ruta2 = fileName;
        }

        public string Guardar(Persona Cliente)
        {
            StreamWriter sw = new StreamWriter(ruta, true);
            sw.WriteLine(Cliente.ToString());
            sw.Close();
            return $"guardado con el nombre de: {Cliente.Nombre}";
        }

        
    }
}