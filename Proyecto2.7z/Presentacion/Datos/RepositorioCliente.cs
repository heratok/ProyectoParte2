﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades;
using System.IO;
namespace Datos
{
    public class RepositorioCliente : Archivo
    {

        public RepositorioCliente() : base()
        {

        }
        public RepositorioCliente(string fileName) : base(fileName)
        {

        }
        public List<Cliente> GetAll()
        {
            try
            {
                StreamReader sr = new StreamReader(ruta);
                List<Cliente> clientes = new List<Cliente>();
                while (!sr.EndOfStream)
                {
                    clientes.Add(Mappear(sr.ReadLine()));
                }
                sr.Close();
                return clientes;
            }
            catch (Exception)
            {

                return null;
            }
            
        }

        Cliente Mappear(string lineaDatos)
        {
            var contacto = new Cliente();

            contacto.Id = int.Parse(lineaDatos.Split(';')[0]);
            contacto.Nombre = (lineaDatos.Split(';')[1]);
            contacto.Telefono = (lineaDatos.Split(';')[2]);
            return contacto;
        }

        public bool Update(List<Cliente> Clientes)
        {
            try
            {
                var sw = new StreamWriter(ruta, false);
                foreach (var item in Clientes)
                {
                    sw.WriteLine(item.ToString());
                }

                sw.Close();

                return true;
            }
            catch (Exception)
            {
                return false;

            }

        }

        
    }
}