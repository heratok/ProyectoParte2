﻿using Datos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class LogicaDatosRecibo : ControldeDatos<Factura>
    {
        List<Factura> factura;
        RepositorioRecibo Repositorio_Recibo;
        
        public LogicaDatosRecibo()
        {
            Repositorio_Recibo = new RepositorioRecibo("Recibo.txt");
            factura = Repositorio_Recibo.GetAll();
        }
        public void Refresh()
        {
            factura = Repositorio_Recibo.GetAll();
        }

        public string Delete(Factura recibos)
        {
            var id = GetByPhone(recibos.Id_Compra1);
            factura.Remove(id);
            Repositorio_Recibo.Update(factura);
            Refresh();
            return $"El Recibo se elimino correctamente con el id de {recibos.Id_Compra1}";
        }

        public string Edit(Factura oldrecibos, Factura Updaterecibos)
        {
            oldrecibos.Id_Compra1 = Updaterecibos.Id_Compra1;
            oldrecibos.Tipo_Carne1 = Updaterecibos.Tipo_Carne1;
            oldrecibos.Precio1 = Updaterecibos.Precio1;
            oldrecibos.Cantidad1 = Updaterecibos.Cantidad1;
            oldrecibos.Sub_Total1 = Updaterecibos.Sub_Total1;
            oldrecibos.Total1 = Updaterecibos.Total1;
            var estado = Repositorio_Recibo.Update(factura);
            Refresh();
            return estado ? $"se actualizo el recibo con id {Updaterecibos.Id_Compra1}" :
                            $"ERROR al actulizar los datos del recibo con id {Updaterecibos.Id_Compra1}";
        }

        public bool Exists(Factura recibos)
        {
            throw new NotImplementedException();
        }

        public List<Factura> GetAll()
        {
            return Repositorio_Recibo.GetAll();
        }

        public Factura GetById(int id)
        {
            foreach(var item in factura)
            {
                if (id == item.Id)
                {
                    return item;
                }
            }
            return null;
        }

        public Factura GetByPhone(string phone)
        {
            throw new NotImplementedException();
        }

        public string Save(Factura recibos)
        {
            Repositorio_Recibo.Guardar(recibos);
            factura = Repositorio_Recibo.GetAll();
            return $"Recibo creado con el id : {recibos.Id_Compra1}";
        }
    }
}
