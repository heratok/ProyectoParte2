﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto
{
    public partial class FrmLogin : Form
    {
        string Usuario = "123";
        string Contraseña = "123";
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bntAceptar_Click(object sender, EventArgs e)
        {
            if(txtUsuario.Text == Usuario && txtContraseña.Text == Contraseña)
            {
                txtUsuario.Clear();
                txtUsuario.Focus();
                txtContraseña.Clear();
                txtContraseña.Focus();
                FrmGestion gestion = new FrmGestion();
                gestion.ShowDialog();
            }
            else
            {
                MessageBox.Show("Datos incorrectos");
                txtUsuario.Clear();
                txtContraseña.Clear();
            }

        }
    }
}
