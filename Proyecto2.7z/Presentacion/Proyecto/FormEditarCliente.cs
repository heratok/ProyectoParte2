﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica;
using Proyecto;

namespace PresentacionGUI
{
    public partial class FormEditarCliente : Form
    {
        LogicaDatosCliente logicaDatosCliente = new LogicaDatosCliente();
        string tel;
        FrmDatosUsuario DatosUsuario = new FrmDatosUsuario();

        public FormEditarCliente()
        {
            InitializeComponent();
            //txtId.Enabled = false;
            txtTelefono.MaxLength = 10;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Editar();
        }


        void Editar()
        {
            var cliente = new Cliente();
            var oldCliente = logicaDatosCliente.GetByPhone(tel);
            cliente.Nombre = txtNombre.Text;
            cliente.Telefono = txtTelefono.Text;
            cliente.Id = int.Parse(txtId.Text);


            var mensaje = logicaDatosCliente.Edit(oldCliente, cliente);
            MessageBox.Show(mensaje, "Editar contacto", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        public void Telefono()
        {
            tel = txtTelefono.Text;
        }

        private void FormEditarFamiliar_Load(object sender, EventArgs e)
        {
            Telefono();
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            DatosUsuario.SoloNumeros(e);
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (DatosUsuario.SoloLetras(e.KeyChar) == false)
            {
                MessageBox.Show("Solo se permiten Letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void FormEditarFamiliar_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtFecha_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            DatosUsuario.SoloNumeros(e);
        }
    }
}
