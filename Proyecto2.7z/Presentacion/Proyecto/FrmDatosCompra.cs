﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Entidades;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using Logica;
using PresentacionGUI;
using Datos;
using System.Security.Cryptography;
using System.Net.Sockets;
using Microsoft.VisualBasic;

namespace Proyecto
{
    public partial class FrmDatosCompra : Form
    {
        LogicaDatosRecibo servicioRecibo = new LogicaDatosRecibo();
        LogicaDatosCliente cliente = new LogicaDatosCliente();
        LogicaDatosCarne carne = new LogicaDatosCarne();

        private DataTable dt;
        private double total = 0;
        private double subtotal = 0;
        private PrintDocument printDocument1;
        private int idClient = 0;

        public FrmDatosCompra()
        {
            InitializeComponent();
           
            dt = new DataTable();
            dt.Columns.Add("Id Compra");
            dt.Columns.Add("Tipo Carne");
            dt.Columns.Add("Precio");
            dt.Columns.Add("Cantidad");
            dt.Columns.Add("Sub Total");

            dataGridView1.DataSource = dt;
            Tipocarne();
        }
       
       
   
        private void FrmDatosCompra_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public void SoloNumeros(KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        public bool SoloLetras(char e)
        {
            if (e >= 65 && e <= 90 || e == 8 || e >= 97 && e <= 122 || e == 32 || e == 165 && e == 164)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void buttonCargarLista_Click(object sender, EventArgs e)
        {
           
                if (textIdCompra.Text != ""  && textPrecio.Text != "" && textCantidad.Text != "")
                {

                    DataRow row = dt.NewRow();
                    row["Id Compra"] = textIdCompra.Text;
                    row["Tipo Carne"] = comboBox1.Text;
                    row["Precio"] = textPrecio.Text;
                    row["Cantidad"] = textCantidad.Text;
                    row["Sub Total"] = (float.Parse(textPrecio.Text) * float.Parse(textCantidad.Text)).ToString();

                    dt.Rows.Add(row);
                    subtotal = (float.Parse(textPrecio.Text) * float.Parse(textCantidad.Text));
                    total = total += subtotal;
                    labelTotalPagar.Text = total.ToString();
                    Guardar();
                    textIdCompra.Text = textPrecio.Text = textCantidad.Text = "";
                     
                }
        }

        private void labelTotalPagar_Click(object sender, EventArgs e)
        {

        }

        private void textBoxEfectivo_TextChanged(object sender, EventArgs e)
        {
            try
            {
                labelDevolucion.Text = (float.Parse(textBoxEfectivo.Text) - float.Parse(labelTotalPagar.Text)).ToString();
            }
            catch
            {
                labelDevolucion.Text = 0.ToString();

            }
        }

        void Tipocarne()
        {
        
            foreach (var item in carne.GetAll())
            {
               comboBox1.Items.Add(item.NombreCarne1);
            }

        }

        private void buttonVerder_Click(object sender, EventArgs e)
        {
            Factura fact = new Factura();
            List<Factura> listFact = new List<Factura>();
            foreach (DataRow row in dt.Rows)
            {
                fact.Id_Compra1 = row["Id Compra"].ToString();
                fact.Tipo_Carne1 = row["Tipo Carne"].ToString();
                fact.Precio1 = row["Precio"].ToString();
                fact.Cantidad1 = row["Cantidad"].ToString();
                fact.Sub_Total1 = row["Sub Total"].ToString();
                fact.Total1 = total.ToString();

                listFact.Add(fact);
            }
            IDdeClientdeCompra();

            printDocument1 = new PrintDocument();
            PrinterSettings ps = new PrinterSettings();
            printDocument1.PrinterSettings = ps;
            printDocument1.PrintPage += printDocument2_PrintPage;
            printDocument1.Print();
        }

        void Guardar()
        {
            Factura recibo = new Factura(); 
            recibo.Id_Compra1 = textIdCompra.Text;
            recibo.Tipo_Carne1 = comboBox1.Items[comboBox1.SelectedIndex].ToString();
            recibo.Precio1 = textPrecio.Text;
            recibo.Cantidad1 = textCantidad.Text;
            recibo.Sub_Total1 = subtotal.ToString();
            recibo.Total1 = total.ToString();
            var mensaje = servicioRecibo.Save(recibo);
            MessageBox.Show(mensaje, "Registro Recibo", MessageBoxButtons.OK, MessageBoxIcon.Information);
       
        }
        void IDdeClientdeCompra()
        {
            idClient = Convert.ToInt32(Interaction.InputBox("Introduzca la ID del cliente que hizo la compra"));

        }
        
        private void Imprimir_PrintPage(object sender, PrintPageEventArgs e)
        {
            
        }

        private void printDocument2_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 14);
            int ancho = 350;
            int y = 20;
            e.Graphics.DrawString("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", font, Brushes.Black, new RectangleF(0, y += 10, ancho, 20));
            e.Graphics.DrawString("|-------Carniceria Mensch-------|", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("Direccion: calle Salzburger Vorstadt 15", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("Telefono: 31456790666" , font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|-----Datos de Cliente-----|", font, Brushes.Black, new RectangleF(0, y += 30, ancho, 20));
            foreach (var item in cliente.GetAll())
            {
                if(idClient == item.Id)
                {
                    e.Graphics.DrawString("ID del cliente: " + item.Id, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                    e.Graphics.DrawString("Nombre de cliente: " + item.Nombre, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                    e.Graphics.DrawString("Telefono de cliente: " + item.Telefono, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                }
                
            }

            e.Graphics.DrawString("|---Datos de Compra---|", font, Brushes.Black, new RectangleF(0, y += 30, ancho, 20));
            foreach (DataRow row in dt.Rows)
            {
                e.Graphics.DrawString("Id de compra: " + row["Id Compra"].ToString() , font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                e.Graphics.DrawString("Tipo de carne: " + row["Tipo Carne"].ToString(), font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                e.Graphics.DrawString("Precio: " + row["Precio"].ToString(), font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                e.Graphics.DrawString("Cantidad: " + row["Cantidad"].ToString(), font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            }
            e.Graphics.DrawString("Sub Total: $" + subtotal, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|--Total---| $" + total, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("-----Gracias por su compra------ ", font, Brushes.Black, new RectangleF(0, y += 40, ancho, 20));
            e.Graphics.DrawString("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", font, Brushes.Black, new RectangleF(0, y += 30, ancho, 20));
        }

        private void textIdCompra_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textBoxEfectivo_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textTipoCarne_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (SoloLetras(e.KeyChar) == false)
            {
                MessageBox.Show("Solo se permiten Letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }
        private void hideSubmenu()
        {
            if (panel1.Visible == true)
                panel1.Visible = false;
            if (panel2.Visible == true)
                panel2.Visible = false;

        }
        private void button_Registro_Click(object sender, EventArgs e)
        {
            var Registrocompra = new FormRegistroCompra();
            Registrocompra.ShowDialog();
            hideSubmenu();

        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

