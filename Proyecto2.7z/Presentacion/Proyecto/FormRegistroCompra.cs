﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Logica;

namespace PresentacionGUI
{
    public partial class FormRegistroCompra : Form
    {
        LogicaDatosRecibo servicioRecibo = new LogicaDatosRecibo();

        public FormRegistroCompra()
        {
            InitializeComponent();
            CargarGrilla();
        }


        void CargarGrilla()
        {
            foreach (var item in servicioRecibo.GetAll())
            {
                GrillaRegistroCompra.Rows.Add(item.Id_Compra1, item.Tipo_Carne1, item.Precio1, item.Cantidad1, item.Sub_Total1, item.Total1);
            }
        }

        private void FormTodosFamiliar_Load(object sender, EventArgs e)
        {

        }

        int fila;
        private void GrillaFamiliar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void GrillaFamiliar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //fila = e.RowIndex;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            


        }

        


        public void Refrescar()
        {
            GrillaRegistroCompra.Rows.Clear();
            GrillaRegistroCompra.Refresh();
            CargarGrilla();

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       


        private void GrillaFamiliar_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            fila = e.RowIndex;
        }

        private void GrillaFamiliar_MouseClick(object sender, MouseEventArgs e)
        {
            //MouseClicDerecho(e);
        }
        private void Editar(Object sender, EventArgs e)
        {
           
        }
        private void CleanSelected(Object sender, EventArgs e)
        {
            
        }

        public void MouseClicDerecho(MouseEventArgs e)
        {
            

        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            

        }

        private void GrillaFamiliar_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }
    }
}

