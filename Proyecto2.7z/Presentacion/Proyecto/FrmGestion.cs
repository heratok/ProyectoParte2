﻿using Datos;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto
{
    public partial class FrmGestion : Form
    {
        LogicaDatosCarne servicioCarne = new LogicaDatosCarne();
        
        public FrmGestion()
        {
            InitializeComponent();
            cargardatos();
        }

        List<string> list = new List<string>();
       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public bool SoloLetras(char e)
        {
            if (e >= 65 && e <= 90 || e == 8 || e >= 97 && e <= 122 || e == 32 || e == 165 && e == 164)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string carnes;
            carnes = textBox1.Text;
            list.Add(carnes);
            guardar();
            comboBox1.DataSource = null;
            comboBox1.DataSource = list;    
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (SoloLetras(e.KeyChar) == false)
            {
                MessageBox.Show("Solo se permiten Letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
            
        }
        void cargardatos()       
        {
            foreach (var item in servicioCarne.GetAll())
            {
                comboBox1.Items.Add(item.NombreCarne1);
            }
        }
        void guardar()
        {
            Carne carnes = new Carne();
            carnes.NombreCarne1 = textBox1.Text;
            var mensaje = servicioCarne.Save(carnes);
            MessageBox.Show(mensaje, "Registro Carne", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
